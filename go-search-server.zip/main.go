package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"cloud.google.com/go/firestore"
	firebase "firebase.google.com/go"
	"google.golang.org/api/iterator"
	"google.golang.org/api/option"
)

//links: facebook Facebook 대소문자 구분!!!!

// --------------------------------- struct types --------------------------------------

// SearchRec Recieve map
type SearchRec struct {
	Search string
}

type callScraperStruct struct {
	//ioutil or goquery
	Type string
	//urls to scrape
	Urls []string
}

// --------------------------------- global variables --------------------------------------
var firebaseClient, fberr = initiateFbClient()

// --------------------------------- mutex var --------------------------------------
var (
	lambdaCountUID = 100
	mutex          sync.Mutex
)

// --------------------------------- logger var --------------------------------------
var (
	loggerFile, _ = os.OpenFile("err.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	logger        = log.New(loggerFile, "Log", log.LstdFlags|log.Lshortfile)
)

// --------------------------------- firebase functions --------------------------------------
// func to start firebase
func initiateFbClient() (returnClient *firestore.Client, err error) {
	opt := option.WithCredentialsJSON([]byte(`{
		"type": "service_account",
		"project_id": "adiy-977d0",
		"private_key_id": "cd62017e6619f8fc58a2830f65bb894aee0c6840",
		"private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCv6n3JX8o298zz\nf9bDQE9QOLNkedBNR0o2vOvT5+N6Ow4y/tsj2b/VYcGM8JgtrtgKIWT+UpEtmLyV\nc0WPidwYX/YP9icZCRZMIunnDvCFKASrz/e8ent1M+ZoThq2rX/Mcnjlg2BEA/az\nbo2+Qfgiag0IWMQYwK0OVDa+UX3jp6+SvpGolbYhNzXlefUUju980rRWtitE88qB\nDq8ZzYA+/+B6edGOv6RH0P6wTXd8y3a+xEOU+eXJ/Pcby3PZlRKBSwUb5maf7mP4\n0m1QfMpxDYDxRvz9Pjq9v8wZLmctf/ulq8w7dEq/FHPkWe9y7F5L5etQ+X9qkDPw\nlS+Zu7KfAgMBAAECggEACDwYraEIymruJ/s01p3/jc33A9M59NbLUBBRlRwBR4Wq\ng/5EdtioxLiB7XLjxMZZrEZk6mImE/WBj8Noya/WjY43FVyHTFeNuNGs6QPc2Xbb\n78kD8UmQgZYviR7C3F33Igm9GWKoJ8xBs6OPX2J01vOSREZCI7XSmV2dfxTkfjrA\nIWcPI+YrhGNwTZyUYLDVm/jhgENeiz430yNHQCj9w7DEhFgyCcofNfFucQedWiqO\nMpf1HMVavXW1V1zwDRNk2o4s9c4hrsIX3zIq5Ag5JqeyBlZYxQ4OoaEgA1uBqxsR\nZqeOSErQmHMsxncZh5M8dPq4ta9VVLn1xlZnOHUGIQKBgQDrThMXdsSbBurdCQop\nMeZh2/d9EfCeqlQl0Z7Pepq8vDNkCf39TwKyhix0A2io6hhtCab9qjEhliRMGOl/\nPFgjDPKcsF2+S2QfdwElrryfH4PLY2Y3wWXxWOMWbiwiye2qeDYTUIo6AFw+GJ7R\neLpf1FTaZ+Av4ajHvkwcLv8xYQKBgQC/Y0PVSzpsH9niXOJz7JIi//VWPjtgvlSs\nw4n82OGh1sj2yloOlE/ISr9WcOs6bppAcyotHUzKsvQf5mPjj+tC0l+KkLALmVxH\nGP3RsPvqYSQudynYxLm6z1/HP7V69B93YKTcaLOq6wyACaF/3AHXutn0aE86zqen\nztulEhFj/wKBgQCoxWEQLVGq1/VRAJDXJ0FU407J2Do7s3OThJxhuFCQGnTJxhj0\nvNz0ayQrOd6xeOZ4Hro1qwJ+UpBKPHwNlJyq1ziUhjNWsABqSRL7ki8b+qCvGuZQ\nC1kxGE4Y4oCpmyfqYzp19AiQvX1r1IDlQbB713HdDTBRZ4uFaMpyVIsZQQKBgEjk\nxNQ7J9BAvVrS58khRHOiK04iu7jYJSX7/9VWwXFDfh1I6s38vPpbRc7liSIjOAru\nEhVGwJW/XO29cTQd/4ve1lbPTs3MJnJJ2XqBPyGAyCgOaNjP7LFzBFa+NB/VVRrB\nq2jrU+r4RTWK9YDeSbFh0FufUvXh+ccXKV8Qp6D/AoGAYeodVAhtyNOUM0wU7/OE\nAFW7EYOWjUVwDMoZkL8B+eUwfbWwzyo783y6w2N+nb7C/0OqQ+pwtDUWibJQu8oF\nhZriB1S3Xo7RyRmvSs+TgpRUuXx1LOfac4w1K10wOh+cTAt0AH4FdRHmquE8Eooj\n15niCYS10E5SQMdj+Iouq/w=\n-----END PRIVATE KEY-----\n",
		"client_email": "firebase-adminsdk-sdyey@adiy-977d0.iam.gserviceaccount.com",
		"client_id": "103733876992635312208",
		"auth_uri": "https://accounts.google.com/o/oauth2/auth",
		"token_uri": "https://oauth2.googleapis.com/token",
		"auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
		"client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-sdyey%40adiy-977d0.iam.gserviceaccount.com"
	  }
	  `))
	// firebase를 생성
	app, err := firebase.NewApp(context.Background(), nil, opt)

	if err != nil {
		return nil, err
	}

	// 유저의 정보를 firestore에서 가져오기
	firebaseClient, err := app.Firestore(context.Background())
	if err != nil {
		return nil, err
	}
	return firebaseClient, nil
}

// func to check if the search query needs to find channels again and refresh
func checkFbIfSearchNeedsRefresh(searchStr string, refreshTime time.Time) (returnBool bool, err error) {
	result, err := firebaseClient.Collection("search").Doc(searchStr).Get(context.Background())
	if err != nil {
		return false, err
	}
	dataTime := result.Data()["LastUpdate"].(time.Time)

	if dataTime.Before(refreshTime) {
		return true, nil
	}
	return false, nil
}

// adds search doc if search doc is not in firebase
func createFbSearchDoc(searchStr string) error {
	_, err := firebaseClient.Collection("search").Doc(searchStr).Set(context.Background(), map[string]interface{}{"LastUpdate": time.Now().UTC()})
	if err != nil {
		return err
	}
	return nil
}

// adds the channel doc if not in firebase
func createFbChannelDoc(searchStr string, addingChans []string) (errAry []error) {
	chError := make(chan error)
	var errorAry []error
	for _, channel := range addingChans {
		channelNoSlash := strings.ReplaceAll(channel, "/", "-")
		// set의 기능은 없으면 넣어주고, 있으면 업데이트를 해주는 아주 편리한 기능이다.
		// 새롷은 체널들은 lastUpdate를 넣지 않는다. 왜나하면 이미 존재하던 정보들도 lastupdate다시 업데이트 되기 때문
		go createFbChannelDocGorutine(searchStr, channel, channelNoSlash, chError)

	}
	for c := 1; c < len(addingChans); {
		select {
		case a := <-chError:
			if a != nil {
				errorAry = append(errorAry, a)
			}
			c++
		}
	}
	return errorAry
}
func createFbChannelDocGorutine(searchStr string, channelWithSlash string, channelNoSlash string, chError chan error) {
	var resultOf []string
	// 미리 안만들어진 체널일 수도 있다.
	result, err := firebaseClient.Collection("channels").Doc(channelNoSlash).Get(context.Background())
	//이미 안만들어진 체널일 경우 / 오류가 발생한 경우
	if err != nil {
		if !strings.Contains(err.Error(), "NotFound desc") {
			// 그냥 오류 발생
			chError <- err
		}
		// 이미 만들어졌던 체널이다.
	} else {
		resOf := result.Data()["ResultOf"]
		if resOf != nil {
			for _, res := range resOf.([]interface{}) {
				resultOf = append(resultOf, res.(string))
			}
		}
	}
	if !contains(resultOf, searchStr) {
		resultOf = append(resultOf, searchStr)
	}
	_, err = firebaseClient.Collection("channels").Doc(channelNoSlash).Set(context.Background(), map[string]interface{}{"ChanUrl": channelWithSlash, "ResultOf": resultOf})
	if err != nil {
		chError <- err
	}
	chError <- nil
}

// func to get channels that needs refreshing
func getFbSearchRelChansThatNeedsRefresh(searchStr string, refreshTime time.Time) (returnArray []string, err error) {
	result := firebaseClient.Collection("channels").Where("ResultOf", "array-contains", searchStr).Documents(context.Background())
	var chanArray []string
	for {
		doc, err := result.Next()
		if err == iterator.Done {
			break
		}
		if err != nil {
			return nil, err
		}
		// 이 라인이 오류가 생길 가능성이 높음
		// 새롷은 체널들은 라스트 업데이트를 안받기 때문

		if doc.Data()["LastUpdate"] == nil {
			if doc.Data()["ChanUrl"] != nil {
				chanURL := doc.Data()["ChanUrl"].(string)
				chanURL = strings.Replace(chanURL, "https://www.youtube.com", "", 1)
				chanURL = strings.Replace(chanURL, "/about", "", 1)
				chanArray = append(chanArray, chanURL)
			}
		} else {
			dataTime := doc.Data()["LastUpdate"].(time.Time)
			if dataTime.Before(refreshTime) {
				if doc.Data()["ChanUrl"] != nil {
					chanURL := doc.Data()["ChanUrl"].(string)
					chanURL = strings.Replace(chanURL, "https://www.youtube.com", "", 1)
					chanURL = strings.Replace(chanURL, "/about", "", 1)
					chanArray = append(chanArray, chanURL)
				}
			}
		}
	}
	return chanArray, nil
}

// 체널 데이터를 firebase에 저장 또는 업데이트
func saveFbChanData(search string, resIntInfo map[int]Info) (errAry []error) {
	chError := make(chan error)
	var errorAry []error
	for _, value := range resIntInfo {
		go saveFbChanDataGorutine(search, value, chError)
	}
	for c := 1; c < len(resIntInfo); {
		select {
		case a := <-chError:
			if a != nil {
				errorAry = append(errorAry, a)
			}
			c++
		}
	}
	return errorAry
}
func saveFbChanDataGorutine(searchStr string, info Info, chError chan error) {

	channel := strings.Replace(info.ChanUrl, "https://www.youtube.com", "", 1)
	channel = strings.Replace(channel, "/about", "", 1)
	channel = strings.ReplaceAll(channel, "/", "-")

	var resultOf []string
	// 미리 안만들어진 체널일 수도 있다.
	result, err := firebaseClient.Collection("channels").Doc(channel).Get(context.Background())
	//이미 안만들어진 체널일 경우 / 오류가 발생한 경우
	if err == nil {
		resOf := result.Data()["ResultOf"]
		if resOf != nil {
			for _, res := range resOf.([]interface{}) {
				resultOf = append(resultOf, res.(string))
			}
		}
	}
	if !contains(resultOf, searchStr) {
		resultOf = append(resultOf, searchStr)
	}

	_, err = firebaseClient.Collection("channels").Doc(channel).Set(context.Background(), map[string]interface{}{
		"ChanUrl":    info.ChanUrl,
		"Channel":    info.Channel,
		"Title":      info.Title,
		"ChanImg":    info.ChanImg,
		"About":      info.About,
		"Subs":       info.Subs,
		"Views":      info.Views,
		"AvrViews":   info.AvrViews,
		"UploadTime": info.UploadTime,
		"Links":      info.Links,
		"Script":     info.Script,
		"ResultOf":   resultOf,
		"LastUpdate": time.Now().UTC(),
	}, firestore.MergeAll)
	if err != nil {
		chError <- err
	}
	chError <- nil
}

// -------------------- juns web filter ------------------------------

// func to get firebase collections reference, the start
func getFbCollectionRefBySearch(collectionName string, searchStr string) (returnQuery firestore.Query) {
	return firebaseClient.Collection(collectionName).Where("ResultOf", "array-contains", searchStr)
}

// func to add avr view filters to collectionRef
func getFbQueryFilteredBySubs(min int, max int, query firestore.Query) (returnQuery firestore.Query) {
	retQuery := query
	if min != 0 {
		retQuery = retQuery.Where("Subs", ">=", min)
	}
	if max != 0 {
		retQuery = retQuery.Where("Subs", "<", max)
	}
	return retQuery
}

// func to add avr view filters to collectionRef
func getFbQueryFilteredByAvrViews(min int, max int, query firestore.Query) (returnQuery firestore.Query) {
	retQuery := query
	if min != 0 {
		retQuery = retQuery.Where("AvrViews", ">=", min)
	}
	if max != 0 {
		retQuery = retQuery.Where("AvrViews", "<", max)
	}
	return retQuery
}

// func to add total view filters to collectionRef
// should rename it to Views -> TotalViews
func getFbQueryFilteredByTotalViews(min int, max int, query firestore.Query) (returnQuery firestore.Query) {
	retQuery := query
	if min != 0 {
		retQuery = retQuery.Where("Views", ">=", min)
	}
	if max != 0 {
		retQuery = retQuery.Where("Views", "<", max)
	}
	return retQuery
}

// func to get results from a query, the last step
func getFbResultDocumentFromQuery(query firestore.Query) (returnInterface map[int]map[string]interface{}, err error) {

	result := query.Documents(context.Background())
	returnInter := make(map[int]map[string]interface{})
	i := 0
	for {
		doc, err := result.Next()
		if err == iterator.Done {
			break
		}
		if err != nil {
			println(err.Error)
			return nil, err
		}
		returnInter[i] = doc.Data()
		i++
	}
	return returnInter, nil
}

func asyncDevideHandler(avrViewMinMax []int, subMinMax []int, totViewMinMax []int, devidedBy int, gotInterface map[int]map[string]interface{}) (returnIntAry []int) {
	devideRes := len(gotInterface) / devidedBy
	devideLeftover := len(gotInterface) % devidedBy
	chanIntAry := make(chan []int)
	// ex (0 52) (53 105) (106 158) remainer (159)
	for i := 0; i < devidedBy+1; i++ {
		if i == devidedBy {
			go asyncDevide(avrViewMinMax, subMinMax, totViewMinMax, i*devideRes, ((i*devideRes)-1)+devideLeftover, chanIntAry, gotInterface)
			break
		}
		go asyncDevide(avrViewMinMax, subMinMax, totViewMinMax, i*devideRes, ((i+1)*devideRes)-1, chanIntAry, gotInterface)
	}
	var finIntAry []int
	for i := 0; i < devidedBy+1; i++ {
		x := <-chanIntAry
		finIntAry = append(finIntAry, x...)
	}
	return finIntAry
}
func asyncDevide(avrViewMinMax []int, subMinMax []int, totViewMinMax []int, fromInt int, toInt int, chanIntAry chan []int, gotInterface map[int]map[string]interface{}) {
	intAry := selfForLoopFiltering(avrViewMinMax, subMinMax, totViewMinMax, fromInt, toInt, gotInterface)
	chanIntAry <- intAry
}
func selfForLoopFiltering(avrViewMinMax []int, subMinMax []int, totViewMinMax []int, from int, to int, gotInterface map[int]map[string]interface{}) (returnInt []int) {
	var intAry []int
	var avrViewCheck bool
	var subsCheck bool
	var totViewCheck bool

	for i := from; i < to+1; i++ {
		avrViewCheck = true
		subsCheck = true
		totViewCheck = true

		if len(avrViewMinMax) != 0 {
			avrViewOriginal := gotInterface[i]["AvrViews"]
			if avrViewOriginal != nil {
				var AvrViews int64
				//convert to int64 by type
				switch avrViewOriginal.(type) {
				case json.Number:
					AvrViews, _ = avrViewOriginal.(json.Number).Int64()
				case int64:
					AvrViews = avrViewOriginal.(int64)
				case int:
					AvrViews = int64(avrViewOriginal.(int))
				}
				if avrViewMinMax[0] != 0 {
					if !(AvrViews >= int64(avrViewMinMax[0])) {
						avrViewCheck = false
					}
				}
				if avrViewMinMax[1] != 0 {
					if !(AvrViews < int64(avrViewMinMax[1])) {
						avrViewCheck = false
					}
				}
			}
		}
		if len(subMinMax) != 0 {
			subsOriginal := gotInterface[i]["Subs"]
			if subsOriginal != nil {
				var Subs int64
				//convert to int64 by type
				switch subsOriginal.(type) {
				case json.Number:
					Subs, _ = subsOriginal.(json.Number).Int64()
				case int64:
					Subs = subsOriginal.(int64)
				case int:
					Subs = int64(subsOriginal.(int))
				}
				if subMinMax[0] != 0 {
					if !(Subs >= int64(subMinMax[0])) {
						subsCheck = false
					}
				}
				if subMinMax[1] != 0 {
					if !(Subs < int64(subMinMax[1])) {
						subsCheck = false
					}
				}
			}
		}
		if len(totViewMinMax) != 0 {
			totViewsOriginal := gotInterface[i]["Views"]
			if gotInterface[i]["Views"] != nil {
				var totViews int64
				//convert to int64 by type
				switch totViewsOriginal.(type) {
				case json.Number:
					totViews, _ = totViewsOriginal.(json.Number).Int64()
				case int64:
					totViews = totViewsOriginal.(int64)
				case int:
					totViews = int64(totViewsOriginal.(int))
				}

				if totViewMinMax[0] != 0 {
					if !(totViews >= int64(totViewMinMax[0])) {
						totViewCheck = false
					}
				}
				if totViewMinMax[1] != 0 {
					if !(totViews < int64(totViewMinMax[1])) {
						totViewCheck = false
					}
				}
			}
		}
		if avrViewCheck == true && subsCheck == true && totViewCheck == true {
			intAry = append(intAry, i)
		}

	}

	return intAry
}

// --------------------------------- server functions --------------------------------------
//http://ec2-54-161-234-228.compute-1.amazonaws.com:3000/master?search=
// http://localhost:3000/master?search=
func main() {
	if fberr != nil {
		fmt.Printf("error: %v\n", fberr.Error())
		logger.Println(fberr.Error())
		return
	}
	fmt.Println("server is up and running")
	http.HandleFunc("/master", handler)
	log.Fatal(http.ListenAndServe(":3000", nil))
}
func handler(w http.ResponseWriter, r *http.Request) {
	//cors. 나중에 한개의 url로 통합할 때 바꾸시오!
	w.Header().Set("Access-Control-Allow-Origin", "*")

	start := time.Now()
	fmt.Println("we got a request on 3000 (master)")

	defer func() {
		elapsed := time.Since(start)
		fmt.Printf("\n")
		fmt.Printf("Binomial took %v\n", elapsed)
	}()

	// searchParams 가져오기
	params, ok := r.URL.Query()["search"]
	if !ok || len(params[0]) < 1 {
		log.Println("Url Param 'search' is missing")
		fmt.Fprintf(w, "You are missing the 'search' param!\n")
		return
	}
	search := params[0]
	avMax := getQueryToIntOrZero("avmax", r)
	avMin := getQueryToIntOrZero("avmin", r)
	sbMax := getQueryToIntOrZero("sbmax", r)
	sbMin := getQueryToIntOrZero("sbmin", r)
	tvMax := getQueryToIntOrZero("tvmin", r)
	tvMin := getQueryToIntOrZero("tvmax", r)
	resultInterface := make(map[int]map[string]interface{})
	intInfo := make(map[int]Info)
	channelBools := make(map[string]bool)
	var getFromFB bool
	needRef, err := checkFbIfSearchNeedsRefresh(search, time.Now().AddDate(0, 0, -1).UTC())
	if err != nil {
		if strings.Contains(err.Error(), "NotFound desc") {
			//serverSideWork를 resultInterface의 형태로 받아야 한다!
			channelBools, intInfo, err = serverSideWorkResponse(search)
			if err != nil {
				fmt.Printf("error :%v\n", err.Error())
				fmt.Fprintf(w, "error %v!\n", err.Error())
				logger.Println(err.Error())
				return
			}
			for intt, info := range intInfo {
				resultInterface[intt] = make(map[string]interface{})
				resultInterface[intt]["ChanUrl"] = info.ChanUrl
				resultInterface[intt]["Channel"] = info.Channel
				resultInterface[intt]["Title"] = info.Title
				resultInterface[intt]["ChanImg"] = info.ChanImg
				resultInterface[intt]["About"] = info.About
				resultInterface[intt]["Subs"] = info.Subs
				resultInterface[intt]["Views"] = info.Views
				resultInterface[intt]["AvrViews"] = info.AvrViews
				resultInterface[intt]["UploadTime"] = info.UploadTime
				resultInterface[intt]["Links"] = info.Links
			}
			getFromFB = false
		}
	} else {
		if needRef {
			//serverSideWork를 resultInterface의 형태로 받아야 한다!
			channelBools, intInfo, err = serverSideWorkResponse(search)
			if err != nil {
				fmt.Printf("error :%v\n", err.Error())
				fmt.Fprintf(w, "error %v!\n", err.Error())
				logger.Println(err.Error())
				return
			}
			for intt, info := range intInfo {
				resultInterface[intt] = make(map[string]interface{})
				resultInterface[intt]["ChanUrl"] = info.ChanUrl
				resultInterface[intt]["Channel"] = info.Channel
				resultInterface[intt]["Title"] = info.Title
				resultInterface[intt]["ChanImg"] = info.ChanImg
				resultInterface[intt]["About"] = info.About
				resultInterface[intt]["Subs"] = info.Subs
				resultInterface[intt]["Views"] = info.Views
				resultInterface[intt]["AvrViews"] = info.AvrViews
				resultInterface[intt]["UploadTime"] = info.UploadTime
				resultInterface[intt]["Links"] = info.Links
			}
			getFromFB = false
		} else {
			getFromFB = true
		}
	}
	if getFromFB {
		Query := getFbCollectionRefBySearch("channels", search)
		if avMin != 0 || avMax != 0 {
			Query = getFbQueryFilteredByAvrViews(avMin, avMax, Query)
			avMin = 0
			avMax = 0
		} else if sbMin != 0 || sbMax != 0 {
			Query = getFbQueryFilteredBySubs(sbMin, sbMax, Query)
			sbMin = 0
			sbMax = 0
		} else if tvMin != 0 || tvMax != 0 {
			Query = getFbQueryFilteredByTotalViews(tvMin, tvMax, Query)
			tvMin = 0
			tvMax = 0
		}
		resultInterface, err = getFbResultDocumentFromQuery(Query)
		if err != nil {
			fmt.Printf("error : %v\n", err)
		}
	}
	var finIntAry []int
	finalInterface := make(map[int]map[string]interface{})

	if !(avMin == 0 && avMax == 0 && sbMin == 0 && sbMax == 0 && tvMin == 0 && tvMax == 0) {
		finIntAry = asyncDevideHandler([]int{avMin, avMax}, []int{sbMin, sbMax}, []int{tvMin, tvMax}, 4, resultInterface)
		for i, val := range finIntAry {
			finalInterface[i] = resultInterface[val]
		}
	} else {
		finalInterface = resultInterface
	}

	bodyJSON, err := json.Marshal(finalInterface)
	if err != nil {
		fmt.Printf("error :%v\n", err.Error())
		fmt.Fprintf(w, "error %v!\n", err.Error())
		logger.Println(err.Error())
		return
	}
	fmt.Fprintf(w, "%s", bodyJSON)

	if !getFromFB {
		go serverSideWorkAfterClean(search, channelBools, intInfo)
	}
}
func serverSideWorkResponse(search string) (stringBoolChannels map[string]bool, intInfo map[int]Info, err error) {
	// 1. 검색어 등록 / 업데이트
	err = createFbSearchDoc(search)
	if err != nil {
		return nil, nil, err
	}
	search, _ = url.PathUnescape(search)
	search = strings.ReplaceAll(search, " ", "+")
	// 2-1. 검색어를 youtube에서 scrape한다.
	urlsArray := []string{
		"https://www.youtube.com/results?search_query=" + search,
		"https://www.youtube.com/results?page=2&search_query=" + search,
		"https://www.youtube.com/results?page=3&search_query=" + search,
		"https://www.youtube.com/results?page=4&search_query=" + search,
		"https://www.youtube.com/results?page=5&search_query=" + search,
		"https://www.youtube.com/results?page=6&search_query=" + search,
		"https://www.youtube.com/results?page=7&search_query=" + search,
		"https://www.youtube.com/results?page=8&search_query=" + search,
		"https://www.youtube.com/results?page=9&search_query=" + search,
		"https://www.youtube.com/results?page=10&search_query=" + search,
		"https://www.youtube.com/results?page=11&search_query=" + search,
		"https://www.youtube.com/results?page=12&search_query=" + search,
		"https://www.youtube.com/results?page=13&search_query=" + search,
		"https://www.youtube.com/results?page=14&search_query=" + search,
		"https://www.youtube.com/results?page=15&search_query=" + search,
		"https://www.youtube.com/results?page=16&search_query=" + search,
		"https://www.youtube.com/results?page=17&search_query=" + search,
		"https://www.youtube.com/results?page=18&search_query=" + search,
		"https://www.youtube.com/results?page=19&search_query=" + search,
		"https://www.youtube.com/results?page=20&search_query=" + search}

	URLStringScript := callScraperHandler(urlsArray, "ioutil")
	stringBoolChannels = findChannelsHandler(URLStringScript)

	aboutUrlsArray := []string{}
	for channel := range stringBoolChannels {
		aboutUrlsArray = append(aboutUrlsArray, "https://www.youtube.com"+channel+"/about")
	}
	videosUrlsArray := []string{}
	for channel := range stringBoolChannels {
		videosUrlsArray = append(videosUrlsArray, "https://www.youtube.com"+channel+"/videos")
	}
	chAbout := make(chan map[string]string)
	chVideos := make(chan map[string]string)
	go func() { chAbout <- callScraperHandler(aboutUrlsArray, "goquery") }()
	go func() { chVideos <- callScraperHandler(videosUrlsArray, "goquery") }()

	URLScriptAbout := <-chAbout
	URLScriptVideos := <-chVideos

	chanInfo := findInfoHandler(URLScriptAbout)
	chanVideosInfo := findVideosInfoHandler(URLScriptVideos)

	i := 0
	intInfo = make(map[int]Info)
	for url, info := range chanInfo {
		info.AvrViews = chanVideosInfo[url].AvrViews
		info.UploadTime = chanVideosInfo[url].UploadTime
		intInfo[i] = info
		i++
	}

	return stringBoolChannels, intInfo, nil
}

func serverSideWorkAfterClean(search string, channelBools map[string]bool, intInfo map[int]Info) {
	start := time.Now()
	// 1. 이미 등록되었는데 검색되지 않은 체널 확인
	needRefChan, err := getFbSearchRelChansThatNeedsRefresh(search, time.Now().AddDate(0, 0, -1).UTC())
	if err != nil {
		fmt.Printf("error := %v\n", err.Error())
		logger.Printf("error := %v\n", err.Error())
	}
	timeTrack(start, "getFbSearchRelChansThatNeedsRefresh")
	start = time.Now()

	var crawlResChans []string
	for str := range channelBools {
		crawlResChans = append(crawlResChans, str)
	}
	needRefChan = subtractStrArray(needRefChan, crawlResChans)

	// 2. 체널 정보 받기
	//이제는 스크레이프를 하고 받아야 한다.!
	aboutUrlsArray := []string{}
	for _, channel := range needRefChan {
		aboutUrlsArray = append(aboutUrlsArray, "https://www.youtube.com"+channel+"/about")
	}
	videosUrlsArray := []string{}
	for _, channel := range needRefChan {
		videosUrlsArray = append(videosUrlsArray, "https://www.youtube.com"+channel+"/videos")
	}
	chAbout := make(chan map[string]string)
	chVideos := make(chan map[string]string)
	go func() { chAbout <- callScraperHandler(aboutUrlsArray, "goquery") }()
	go func() { chVideos <- callScraperHandler(videosUrlsArray, "goquery") }()

	URLScriptAbout := <-chAbout
	URLScriptVideos := <-chVideos

	chanInfo := findInfoHandler(URLScriptAbout)
	chanVideosInfo := findVideosInfoHandler(URLScriptVideos)

	i := 0
	for url, info := range chanInfo {
		info.AvrViews = chanVideosInfo[url].AvrViews
		info.UploadTime = chanVideosInfo[url].UploadTime
		intInfo[len(intInfo)+i] = info
		i++
	}
	errAry := saveFbChanData(search, intInfo)
	timeTrack(start, "saveFbChanData")
	if len(errAry) != 0 {
		for _, err := range errAry {
			fmt.Printf("error := %v\n", err.Error())
			logger.Printf("error := %v\n", err.Error())
		}
	}
}

// --------------------------------- crawl functions --------------------------------------
func findChannelsHandler(urlScript map[string]string) (foundUrls map[string]bool) {
	foundUrls = make(map[string]bool)
	chUrls := make(chan []string)
	chFinished := make(chan bool)

	for _, s := range urlScript {
		go findChannels(s, chUrls, chFinished)
	}
	for c := 0; c < len(urlScript); {
		select {
		case url := <-chUrls:
			for i := range url {
				foundUrls[url[i]] = true
			}
		case <-chFinished:
			c++
		}
	}
	return foundUrls
}
func findChannels(s string, ch chan []string, chFinished chan bool) {
	var channels []string
	// capcha type 1
	if between(string(s), "<script>", "</script>") ==
		"var submitCallback = function(response) {document.getElementById('captcha-form').submit();};" {
		logger.Printf("Capcha has been detected. (crawlVideo) type 1 \n")
		fmt.Printf("error :%v\n", "Capcha has been detected. (crawlVideo) type 1")
	}
	// capcha type 2
	if strings.Contains(between(s, "<script src", "script>"), "https://www.google.com/recaptcha/api.js") == true {
		logger.Printf("Capcha has been detected. (crawlVideo) type 2\n")
		fmt.Printf("error :%v\n", "Capcha has been detected. (crawlVideo) type 2")
	}
	// capcha type 3
	if strings.Contains(between(s, "<script  src", "script>"), "https://www.google.com/recaptcha/api.js") == true {
		logger.Printf("Capcha has been detected. (crawlVideo) type 3\n")
		fmt.Printf("error :%v\n", "Capcha has been detected. (crawlVideo) type 3")
	}
	z := strings.Split(s, "\"commandMetadata\"")
	for val := range z {
		linkPre := between(z[val], "webCommandMetadata", "}")
		linkPre = between(linkPre, "{\"url\":\"", "\"")
		if strings.Index(linkPre, "/channel/") == 0 {
			if !contains(channels, linkPre) {
				channels = append(channels, linkPre)
			}
		}
		if strings.Index(linkPre, "/user/") == 0 {
			if !contains(channels, linkPre) {
				channels = append(channels, linkPre)
			}
		}
	}
	defer func() {
		ch <- channels
		chFinished <- true
	}()
}

//VideosInfo of channel
type VideosInfo struct {
	Channel    string
	UploadTime string
	AvrViews   int
}

func findVideosInfoHandler(urlScript map[string]string) (finalVideosInfo map[string]VideosInfo) {
	finalVideosInfo = make(map[string]VideosInfo)
	chVideosInfo := make(chan VideosInfo)
	chFinished := make(chan bool)

	for url, s := range urlScript {
		go findVideosInfo(url, s, chVideosInfo, chFinished)
	}
	for c := 0; c < len(urlScript); {
		select {
		case videosInfo := <-chVideosInfo:
			finalVideosInfo[videosInfo.Channel] = videosInfo
		case <-chFinished:
			c++
		}
	}
	return finalVideosInfo
}
func findVideosInfo(url string, s string, chVideosInfo chan VideosInfo, chFinished chan bool) {
	storeVideosInfo := VideosInfo{
		Channel:    between(url, "https://www.youtube.com", "/videos"),
		UploadTime: "",
		AvrViews:   0,
	}
	viewsArray := strings.Split(s, "shortViewCountText\":{\"simpleText\":\"")
	// println(len(viewsArray))
	for i := range viewsArray {
		viewsArray[i] = before(viewsArray[i], "\"")
	}

	datesArray := strings.Split(s, "publishedTimeText\":{\"simpleText\":\"")
	// println(len(datesArray))
	for i := range datesArray {
		datesArray[i] = before(datesArray[i], "\"")
	}

	// storeInfo.AvrViews = viewsArray[1]
	if len(datesArray) > 1 {
		storeVideosInfo.UploadTime = datesArray[1]
	}
	p := 0
	var sum int
	var addcnt int
	if len(viewsArray) > len(datesArray) {
		p = len(datesArray)
	} else {
		p = len(viewsArray)
	}
	reg, _ := regexp.Compile("[^0-9.]+")
	for c := 0; c < p; c++ {
		if isWithinYear(datesArray[c]) == true {
			m := checkViewsMultiplyer(viewsArray[c])
			viewsArray[c] = reg.ReplaceAllString(viewsArray[c], "")
			viewFloat, err := strconv.ParseFloat(viewsArray[c], 64)
			viewInt := int(viewFloat * m)
			if err != nil {
			} else {
				addcnt++
				sum += viewInt
			}
		}
	}
	if addcnt == 0 {
		addcnt = 1
	}
	storeVideosInfo.AvrViews = sum / addcnt
	defer func() {
		chVideosInfo <- storeVideosInfo
		chFinished <- true
	}()
}

// Info of channel
type Info struct {
	ChanUrl    string
	Channel    string
	Title      string
	ChanImg    string
	About      string
	Subs       int
	Views      int
	AvrViews   int
	UploadTime string
	Links      map[string]string
	Script     string
}

func findInfoHandler(urlScript map[string]string) (finalStringInfo map[string]Info) {
	// get channel info
	finalStringInfo = make(map[string]Info)
	// finalStringInfo := []Info{}
	chanInfo := make(chan Info)
	chFinished := make(chan bool)

	// Kick off the crawl process (concurrently)
	for url, s := range urlScript {
		go findInfo(url, s, chanInfo, chFinished)
		// 15개의 첫 페이지 체널들만 보냅니다.
	}
	// Subscribe to both channels
	for c := 0; c < len(urlScript); {
		select {
		case info := <-chanInfo:
			finalStringInfo[info.Channel] = info
		case <-chFinished:
			c++
		}
	}
	return finalStringInfo
}
func findInfo(chanURL string, s string, chanInfo chan Info, chFinished chan bool) {
	storeInfo := Info{
		ChanUrl:    chanURL,
		Channel:    between(chanURL, "https://www.youtube.com", "/about"),
		Title:      "",
		ChanImg:    "",
		About:      "",
		Subs:       0,
		Views:      0,
		AvrViews:   0,
		UploadTime: "",
		Links: map[string]string{
			"FacebookGroup": "",
			"FacebookPage":  "",
			"Facebook":      "",
			"Twitch":        "",
			"Instagram":     "",
			"Twitter":       "",
		},
		Script: "",
	}
	// capcha type 1
	if between(string(s), "<script>", "</script>") ==
		"var submitCallback = function(response) {document.getElementById('captcha-form').submit();};" {
		logger.Printf("Capcha has been detected. (crawlVideo) type 1 \n")
		fmt.Printf("error :%v\n", "Capcha has been detected. (crawlVideo) type 1")
	}
	// capcha type 2
	if strings.Contains(between(s, "<script src", "script>"), "https://www.google.com/recaptcha/api.js") == true {
		logger.Printf("Capcha has been detected. (crawlVideo) type 2\n")
		fmt.Printf("error :%v\n", "Capcha has been detected. (crawlVideo) type 2")
	}
	// capcha type 3
	if strings.Contains(between(s, "<script  src", "script>"), "https://www.google.com/recaptcha/api.js") == true {
		logger.Printf("Capcha has been detected. (crawlVideo) type 3\n")
		fmt.Printf("error :%v\n", "Capcha has been detected. (crawlVideo) type 3")
	}
	defer func() {
		chanInfo <- storeInfo
		chFinished <- true
	}()
	// check autogenerated by youtube
	if strings.Contains(s, "Auto-generated by YouTube") {
		logger.Printf("Auto-generation has been detected\n")
		fmt.Printf("Auto-generation has been detected\n")
	}
	if strings.Contains(s, "autoGenerated") {
		logger.Printf("Auto-generation has been detected\n")
		fmt.Printf("Auto-generation has been detected\n")
	}

	// title
	title := between(s, "channelMetadataRenderer\":{\"title\":\"", "\"")
	storeInfo.Title += title
	//channel img
	img := between(s, "\"avatar\":{\"thumbnails\":[{\"url\":\"", "\"")
	storeInfo.ChanImg += img
	// total views
	views := between(s, "viewCountText", ",\"")
	storeInfo.Views += removeButNumber(views)
	// abouts
	abouts := after(s, "\"channelMetadataRenderer\":{\"title\":\"")
	abouts = between(abouts, "description\":\"", "\",\"")
	storeInfo.About += abouts
	//subs
	subs := after(s, "subscriberCountText")
	subs = before(subs, "\"}")
	subs = after(subs, "\":\"")
	subs = strings.Replace(subs, "subscribers", "", 1)
	storeInfo.Subs = subscriberStringToInt(subs)
	//links
	linksPre := between(s, "primaryLinks\":", "channelMetadataRenderer")
	linksArray := strings.Split(linksPre, "thumbnails")
	for val := range linksArray {
		//links
		link := after(linksArray[val], "urlEndpoint")
		link = between(link, "q=", "\"")
		if strings.Contains(link, "\\u0026") {
			link = before(link, "\\u0026")
		}
		decodedValue, _ := url.PathUnescape(link)
		if decodedValue != "" {
			//title
			title := between(linksArray[val], "title\":", "}}")
			title = between(title, ":\"", "\"")
			urlTitle, sucss := checkForSocial(decodedValue)
			if sucss {
				storeInfo.Links[urlTitle] = decodedValue
			}
		}
	}
	return
}

func callScraperHandler(urlArray []string, scrapeType string) (finalURLScripts map[string]string) {
	start := time.Now()

	finalURLScripts = make(map[string]string)
	chanURLScripts := make(chan map[string]string)
	chFinished := make(chan bool)

	devider := 3
	quotient, remainder := len(urlArray)/devider, len(urlArray)%devider
	for i := 0; i < quotient; i++ {
		go callScraper(urlArray[i*devider:((i+1)*devider)], scrapeType, chanURLScripts, chFinished)
	}
	adder := 0
	if remainder != 0 {
		go callScraper(urlArray[quotient*devider:quotient*devider+remainder], scrapeType, chanURLScripts, chFinished)
		adder++
	}
	for i := 0; i < quotient+adder; {
		select {
		case URLScripts := <-chanURLScripts:
			for url, script := range URLScripts {
				finalURLScripts[url] = script
			}
		case <-chFinished:
			i++
		}
	}
	timeTrack(start, "callScraperHandler")
	return finalURLScripts
}
func callScraper(urls []string, callType string, chanURLScripts chan map[string]string, chFinished chan bool) {
	bodyMap := callScraperStruct{
		Type: callType,
		Urls: urls,
	}
	bodyJSON, _ := json.Marshal(bodyMap)
	client := &http.Client{}
	mutex.Lock()
	lambdaCount := lambdaCountUID
	lambdaCountUID++
	if lambdaCountUID >= 200 {
		lambdaCountUID = 0
	}
	mutex.Unlock()
	request, _ := http.NewRequest("POST", "https://1vzze2ned9.execute-api.us-east-1.amazonaws.com/default/test/go-scraper-"+strconv.Itoa(lambdaCount), bytes.NewBuffer(bodyJSON))
	response, _ := client.Do(request)
	body, _ := ioutil.ReadAll(response.Body)
	URLScripts := make(map[string]string)
	json.Unmarshal(body, &URLScripts)

	response.Body.Close()
	chanURLScripts <- URLScripts
	chFinished <- true
}

// --------------------------------- additional functions --------------------------------------
func subtractStrArray(a []string, b []string) []string {
	// Turn b into a map
	var m map[string]bool
	m = make(map[string]bool, len(b))
	for _, s := range b {
		m[s] = false
	}
	// Append values from the longest slice that don't exist in the map
	var diff []string
	for _, s := range a {
		if _, ok := m[s]; !ok {
			diff = append(diff, s)
			continue
		}
		m[s] = true
	}
	// Sort the resulting slice
	sort.Strings(diff)
	return diff
}
func contains(arr []string, str string) bool {
	for _, a := range arr {
		if a == str {
			return true
		}
	}
	return false
}
func between(str string, start string, end string) (result string) {
	s := strings.Index(str, start)
	if s == -1 {
		return
	}
	s += len(start)
	e := strings.Index(str[s:], end)
	if e == -1 {
		return
	}
	return str[s : s+e]
}
func after(value string, a string) string {
	// Get substring after a string.
	pos := strings.LastIndex(value, a)
	if pos == -1 {
		return ""
	}
	adjustedPos := pos + len(a)
	if adjustedPos >= len(value) {
		return ""
	}
	return value[adjustedPos:len(value)]
}
func before(value string, a string) string {
	pos := strings.Index(value, a)
	if pos == -1 {
		return ""
	}
	return value[0:pos]
}
func removeAllSpecial(from string) string {
	reg, err := regexp.Compile("[^a-zA-Z0-9.]+")
	if err != nil {
		log.Fatal(err)
	}
	processedString := reg.ReplaceAllString(from, "")
	return processedString
}
func removeButNumber(from string) int {
	if from == "" {
		return 0
	}
	reg, err := regexp.Compile("[^0-9]+")
	if err != nil {
		fmt.Printf("error: %v\n", err.Error())
		logger.Println(err.Error())
	}
	processedInt, err := strconv.Atoi(reg.ReplaceAllString(from, ""))
	if err != nil {
		fmt.Printf("error: %v\n", err.Error())
		logger.Println(err.Error())
	}
	return processedInt
}
func removeButFloat(from string) (returnFloat float64, err error) {
	reg, err := regexp.Compile("[^0-9.]+")
	if err != nil {
		return 0, err
	}
	processedString := reg.ReplaceAllString(from, "")
	resFloat, err := strconv.ParseFloat(processedString, 64)
	if err != nil {
		return 0, err

	}
	return resFloat, nil
}
func checkForSocial(value string) (string, bool) {
	if strings.Contains(value, "facebook.com/groups") {
		return "FacebookGroup", true
	}
	if strings.Contains(value, "facebook.com/pages") {
		return "FacebookPage", true
	}
	if strings.Contains(value, "facebook") {
		return "Facebook", true
	}
	if strings.Contains(value, "twitch") {
		return "Twitch", true
	}
	if strings.Contains(value, "instagram") {
		return "Instagram", true
	}
	if strings.Contains(value, "twitter") {
		return "Twitter", true
	}
	return "", false
}
func isWithinYear(stringData string) bool {
	if strings.Contains(stringData, "day") {
		return true
	}
	if strings.Contains(stringData, "week") {
		return true
	}
	if strings.Contains(stringData, "month") {
		return true
	}
	if strings.Contains(stringData, "일") {
		return true
	}
	if strings.Contains(stringData, "주") {
		return true
	}
	return false
}
func checkViewsMultiplyer(stringData string) float64 {
	if strings.Contains(stringData, "천") {
		return 1000
	}
	if strings.Contains(stringData, "만") {
		return 10000
	}
	if strings.Contains(stringData, "K") {
		return 1000
	}
	if strings.Contains(stringData, "M") {
		return 1000000
	}
	if strings.Contains(stringData, "B") {
		return 1000000000
	}
	return 1
}
func subscriberStringToInt(stringData string) int {
	if stringData == "" {
		return 0
	}
	var multiplier float64 = 1
	gotInt, err := removeButFloat(stringData)
	if err != nil {
		fmt.Printf("subscriberStringToInt error from string %v\n", stringData)
		fmt.Printf("error: %v\n", err.Error())
		logger.Printf("subscriberStringToInt error from string %v\n", stringData)
		logger.Println(err.Error())
		return 0
	}
	if strings.Contains(stringData, "천") {
		multiplier = 1000
	}
	if strings.Contains(stringData, "만") {
		multiplier = 10000
	}
	if strings.Contains(stringData, "억") {
		multiplier = 100000000
	}
	if strings.Contains(stringData, "K") {
		multiplier = 1000
	}
	if strings.Contains(stringData, "M") {
		multiplier = 1000000
	}
	if strings.Contains(stringData, "B") {
		multiplier = 1000000000
	}
	resInt := int(gotInt * multiplier)
	return resInt
}
func timeTrack(start time.Time, name string) {
	elapsed := time.Since(start)
	log.Printf("%s took %s\n", name, elapsed)
}
func getQueryToIntOrZero(query string, r *http.Request) int {
	params, ok := r.URL.Query()[query]
	if !ok || len(params) == 0 {
		return 0
	}
	value, err := strconv.Atoi(params[0])
	if err != nil {
		return 0
	}
	return value
}
func readTxtFile(fileName string) string {
	file, err := os.Open(fileName)
	if err != nil {
		fmt.Printf("error :%v\n", err.Error())
		return ""
	}
	defer file.Close()
	s, err := ioutil.ReadAll(file)
	if err != nil {
		fmt.Printf("error :%v\n", err.Error())
		return ""
	}
	return string(s)
}
