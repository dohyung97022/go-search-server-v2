# go-search-server-v2
changing search server to v2
